# UserConfigEnum.py
# (C)2013
# Scott Ernst

#___________________________________________________________________________________________________ UserConfigEnum
class UserConfigEnum(object):
    """A class for..."""

#===================================================================================================
#                                                                                       C L A S S

    LAST_BROWSE_PATH = 'LAST_BROWSE_PATH'

    NIMBLE_TEST_STATUS = 'NIMBLE_TEST_STATUS'
